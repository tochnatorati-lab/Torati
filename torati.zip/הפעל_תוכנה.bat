@echo off
title Torah Notes Manager - Local Server
cd /d "%~dp0"

echo Starting local server...
echo.

where python >nul 2>nul
if %errorlevel%==0 (
    start "" http://localhost:8951/torah_app.html
    python torati_server.py
    goto :eof
)

where python3 >nul 2>nul
if %errorlevel%==0 (
    start "" http://localhost:8951/torah_app.html
    python3 torati_server.py
    goto :eof
)

echo Python was not found on this computer.
echo.
echo You can install Python for free from:
echo https://www.python.org/downloads/
echo (During installation, check "Add Python to PATH")
echo.
echo Alternatively, you can use the app without installing anything -
echo just open torah_app.html directly in your browser.
echo.
pause
